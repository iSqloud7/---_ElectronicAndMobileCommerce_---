package mk.ukim.finki.fooddeliverybackend.model.enums;

public enum OrderStatus {
    PENDING,
    CONFIRMED,
    CANCELED,
}
